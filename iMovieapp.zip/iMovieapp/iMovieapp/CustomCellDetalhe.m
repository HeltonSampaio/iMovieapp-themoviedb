//
//  CustomCellDetalhe.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 03/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import "CustomCellDetalhe.h"

@interface CustomCellDetalhe ()

@property (weak, nonatomic) IBOutlet UIImageView *imageViewPoster;
@property (weak, nonatomic) IBOutlet UIImageView *imageViewStar;

@property (weak, nonatomic) IBOutlet UILabel *labelAno;
@property (weak, nonatomic) IBOutlet UILabel *labelData;
@property (weak, nonatomic) IBOutlet UILabel *labelIdioma;
@property (weak, nonatomic) IBOutlet UILabel *labelDsIdioma;
@property (weak, nonatomic) IBOutlet UILabel *labelGenero;
@property (weak, nonatomic) IBOutlet UILabel *labelPopularidade;
@property (weak, nonatomic) IBOutlet UILabel *labelMedia;
@property (weak, nonatomic) IBOutlet UILabel *labelDsMedia;

@property (weak, nonatomic) IBOutlet UITextView *txtViewDsGenero;


@end

@implementation CustomCellDetalhe

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
}

#pragma mark - variaveis

- (void)setLblAno:(NSString *)lblAno
{
    self.labelAno.text = lblAno;
}

- (NSString *)lblAno
{
    return self.labelAno.text;
}

- (void)setLblData:(NSString *)lblData
{
    self.labelData.text = lblData;
}

- (NSString *)lblData
{
    return self.labelData.text;
}

- (void)setLblDsIdioma:(NSString *)lblDsIdioma
{
    self.labelDsIdioma.text = lblDsIdioma;
}

- (NSString *)lblDsIdioma
{
    return self.labelDsIdioma.text;
}

- (void)setLblDsMedia:(NSString *)lblDsMedia
{
    self.labelDsMedia.text = lblDsMedia;
}

- (NSString *)lblDsMedia
{
    return self.labelMedia.text;
}

- (void)setLblGenero:(NSString *)lblGenero
{
    self.labelGenero.text = lblGenero;
}

- (NSString *)lblGenero
{
    return self.labelGenero.text;
}

- (void)setLblIdioma:(NSString *)lblIdioma
{
    self.labelIdioma.text = lblIdioma;
}

- (NSString *)lblIdioma
{
    return self.labelIdioma.text;
}

- (void)setLblMedia:(NSString *)lblMedia
{
    self.labelMedia.text = lblMedia;
}

- (NSString *)lblMedia
{
    return self.labelMedia.text;
}

- (void)setLblPopularidade:(NSString *)lblPopularidade
{
    self.labelPopularidade.text = lblPopularidade;
}

- (NSString *)lblPopularidade
{
    return self.labelPopularidade.text;
}

- (void)setImagePoster:(UIImage *)imagePoster
{
    self.imageViewPoster.image = imagePoster;
}

- (UIImage *)imagePoster
{
    return self.imageViewPoster.image;
}

- (void)setImageStar:(UIImage *)imageStar
{
    self.imageViewStar.image = imageStar;
}

- (UIImage *)imageStar
{
    return self.imageViewStar.image;
}

- (void)setTxtDsGenero:(NSString *)txtDsGenero
{
    self.txtViewDsGenero.text = txtDsGenero;
}

- (NSString *)txtDsGenero
{
    return self.txtViewDsGenero.text;
}


@end
