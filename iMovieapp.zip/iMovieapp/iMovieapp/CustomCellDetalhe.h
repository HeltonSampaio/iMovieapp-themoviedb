//
//  CustomCellDetalhe.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 03/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellDetalhe : UITableViewCell

@property (nonatomic, strong) UIImage *imagePoster;
@property (nonatomic, strong) UIImage *imageStar;

@property (nonatomic, strong) NSString *lblAno;
@property (nonatomic, strong) NSString *lblData;
@property (nonatomic, strong) NSString *lblIdioma;
@property (nonatomic, strong) NSString *lblDsIdioma;
@property (nonatomic, strong) NSString *lblGenero;
@property (nonatomic, strong) NSString *lblPopularidade;
@property (nonatomic, strong) NSString *lblMedia;
@property (nonatomic, strong) NSString *lblDsMedia;

@property (nonatomic, strong) NSString *txtDsGenero;

@end
