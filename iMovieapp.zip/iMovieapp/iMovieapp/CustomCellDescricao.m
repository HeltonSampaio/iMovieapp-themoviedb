//
//  CustomCellDescricao.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 03/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import "CustomCellDescricao.h"

@interface CustomCellDescricao ()

@property (weak, nonatomic) IBOutlet UITextView *txtViewDescricao;

@end

@implementation CustomCellDescricao

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
//    self.txtViewDescricao.backgroundColor = [UIColor redColor];
    
    self.txtViewDescricao.frame = CGRectMake(self.txtViewDescricao.frame.origin.x, self.txtViewDescricao.frame.origin.y, [[UIScreen mainScreen] bounds].size.width - 10, self.txtViewDescricao.frame.size.height);
    
}

#pragma mark - variaveis

- (void)setTxtDescricao:(NSString *)txtDescricao
{
    self.txtViewDescricao.text = txtDescricao;
}

- (NSString *)txtDescricao
{
    return self.txtViewDescricao.text;
}


@end
