//
//  CustomCellDescricao.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 03/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellDescricao : UITableViewCell

@property (nonatomic, strong) NSString* txtDescricao;

@end
