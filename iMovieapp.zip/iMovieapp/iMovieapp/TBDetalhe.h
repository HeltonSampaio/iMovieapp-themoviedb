//
//  TBDetalhe.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 03/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBDetalhe : UITableViewController

@property (nonatomic) NSString *idFilme;
@property (nonatomic) NSDictionary *dicDescFilme;
@property (nonatomic) UIImage *imageFilme;

@property (nonatomic, readonly) NSString *chaveApi;
@property (nonatomic, readonly) NSString *baseURLImagens;
@property (nonatomic, readonly) NSString *baseURLAPI;


@end
