//
//  TBDetalhe.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 03/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import "TBDetalhe.h"
#import "CustomCellDescricao.h"
#import "CustomCellDetalhe.h"
#import "CustomCellTitulo.h"


#define CHAVE_API             @"" // Digite sua chave do API
#define BASE_URL_API          @"https://api.themoviedb.org/3"
#define BASE_URL_IMAGEM       @"http://image.tmdb.org/t/p/original"


@interface TBDetalhe ()

@property (strong, nonatomic) IBOutlet UIBarButtonItem *botaoVoltar;

- (IBAction)btnVoltar:(id)sender;

@end

@implementation TBDetalhe
{
    NSDictionary *dicGeneros;
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
        
        
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.alwaysBounceVertical = NO;
    
    dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        // popula o array de genero do filme
        [self retornaGeneroFilme];
        
    });
}

- (void)viewWillAppear:(BOOL)animated
{
    [self.tableView reloadData];
    [super viewWillAppear:YES];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row)
    {
        case 0: return 97; break;  // Titulo
        case 1: return 281; break;   // Detalhe
        case 2: return 226; break;  // Descrição
            
        default: return 0; break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.row)
    {
        case 0:
        {
            static NSString *identifier = @"CellTitulo";
            
            CustomCellTitulo *cell = [tableView dequeueReusableCellWithIdentifier:identifier forIndexPath:indexPath];
            
            cell.lblTitulo = [_dicDescFilme objectForKey:@"original_title"];
            
//            [cell setBackgroundColor:[UIColor whiteColor]];
            [cell setUserInteractionEnabled:NO];
            
            return cell;
            
        } break;
            
        case 1:
        {
            static NSString *identifier = @"CellDetalhe";
            
            CustomCellDetalhe *cell = [tableView dequeueReusableCellWithIdentifier:identifier forIndexPath:indexPath];
            
            cell.lblData = [_dicDescFilme objectForKey:@"release_date"];
            
            // Extrai o nome e a extensão do arquivo.
            NSArray *filepart = [cell.lblData componentsSeparatedByString:@"-"];
            NSString *ano = [filepart objectAtIndex:0];
            
            cell.lblAno = ano;
            cell.lblIdioma  = @"Language: ";
            cell.lblDsIdioma = [_dicDescFilme objectForKey:@"original_language"];
            cell.lblGenero = @"Genre: ";
            cell.txtDsGenero = [self montaStringGeneros];
            cell.lblPopularidade = [NSString stringWithFormat:@"%@", [_dicDescFilme objectForKey:@"popularity"]];
            cell.lblMedia = @"Average: ";
            cell.lblDsMedia = [NSString stringWithFormat:@"%@/10", [_dicDescFilme objectForKey:@"vote_average"]];
            
            cell.imagePoster = self.imageFilme;
            cell.imageStar = [UIImage imageNamed:@"star"];
            
//            [cell setBackgroundColor:[UIColor whiteColor]];
            [cell setUserInteractionEnabled:NO];
            
            return cell;
            
        } break;
        
        case 2:
        {
            static NSString *identifier = @"CellDescricao";
            
            CustomCellDescricao *cell = [tableView dequeueReusableCellWithIdentifier:identifier forIndexPath:indexPath];
            
            cell.txtDescricao = [_dicDescFilme objectForKey:@"overview"];
            
//            [cell setBackgroundColor:[UIColor clearColor]];
            [cell setUserInteractionEnabled:NO];
            
            return cell;
            
        } break;
            
        default: return nil; break;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
        
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

#pragma mark - Monta Genero

- (NSString *)montaStringGeneros
{
    NSArray *arrayIdGeneros = [_dicDescFilme objectForKey:@"genre_ids"];
    NSArray *generos = [dicGeneros objectForKey:@"genre"];
    
    NSString *strGeneros = @"";
    
    for (int i = 0; i < arrayIdGeneros.count; i++)
    {
        int id_genero = [arrayIdGeneros[i] intValue];
        
        for (int j = 0; j < generos.count; i++)
        {
            int id_ = [[[generos objectAtIndex:j] objectForKey:@"id"] intValue];
            
            if (id_ == id_genero)
                strGeneros = [NSString stringWithFormat:@"%@%@", strGeneros, [[generos objectAtIndex:j] objectForKey:@"name"]];
        }
        
        if ((i+1) == dicGeneros.count)
            strGeneros = [NSString stringWithFormat:@"%@.", strGeneros];
        else if (![strGeneros isEqualToString:@""])
            strGeneros = [NSString stringWithFormat:@"%@, ", strGeneros];
    }
    
    return strGeneros;
}

#pragma Eventos dp API

- (void)retornaGeneroFilme
{
    NSString *urlString = [NSString stringWithFormat:@"%@/genre/movie/list?api_key=%@", self.baseURLAPI, self.chaveApi];
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *err)
     {
         if(data)
         {
             dicGeneros = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
         }
         else
             dicGeneros = nil;
     }];
}


#pragma mark - Botoes

- (IBAction)btnVoltar:(id)sender
{
    [self.navigationController setToolbarHidden:NO animated:YES];
    
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - montando propriedades

- (NSString *)chaveApi
{
    return CHAVE_API;
}

- (NSString *)baseURLAPI
{
    return BASE_URL_API;
}

- (NSString *)baseURLImagens
{
    return BASE_URL_IMAGEM;
}





@end
