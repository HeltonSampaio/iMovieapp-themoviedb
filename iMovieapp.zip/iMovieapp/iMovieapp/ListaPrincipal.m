//
//  ListaPrincipal.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 02/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import "ListaPrincipal.h"
#import "TBDetalhe.h"

#define CHAVE_API             @"" // Digite sua chave do API
#define BASE_URL_API          @"http://api.themoviedb.org/3"
#define BASE_URL_IMAGEM       @"http://image.tmdb.org/t/p/original"

static NSOperationQueue *queue;

@interface ListaPrincipal ()

@property (strong, nonatomic) CCKFNavDrawer *rootNav;

@property (strong, nonatomic) IBOutlet UIView *viewTodo;

@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *botaoVoltar;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *botaoPraFrente;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *contadorPaginas;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *botaoMenu;

- (IBAction)brnPraFrente:(id)sender;
- (IBAction)btnVoltar:(id)sender;
- (IBAction)btnMenu:(id)sender;


@end

@implementation ListaPrincipal
{
    NSDictionary *dicConfiguracao, *dicImagens, *dicFilmes;
    int intContPaginas, intTotalPaginas;
    NSString *strFiltro;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // inicializando os dicionarios
    dicConfiguracao = [NSDictionary dictionary];
    dicFilmes = [NSDictionary dictionary];
    dicImagens = [NSDictionary dictionary];
    
    // inicializar paginas
    intContPaginas = 1;
    
    // inicializando filtro
    strFiltro = @"";
    
    // inicializando o queue
    queue = [[NSOperationQueue alloc] init];
    queue.maxConcurrentOperationCount = 10;

    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    
    
    dispatch_sync(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        // popula o dicionario de filmes
        [self retornaFilmes];
        
    });

}

- (void)viewDidLayoutSubviews
{
    self.navigationController.navigationBar.topItem.title = @"iMovieapp";
    
    [self.navigationController setToolbarHidden:NO animated:YES];
    
    if (intContPaginas > 1)
        [self.botaoVoltar setEnabled:YES];
    else
        [self.botaoVoltar setEnabled:NO];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.rootNav = (CCKFNavDrawer *)self.navigationController;
    [self.rootNav setCCKFNavDrawerDelegate:self];
    
    [self.collectionView reloadData];
    [super viewWillAppear:YES];
}

#pragma mark - Função do Collection View

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    // Codigo para o banco de dados
    
    NSArray *arrayFilmes = [dicFilmes objectForKey:@"results"];
    
    intTotalPaginas = [[dicFilmes objectForKey:@"total_pages"] intValue];
    self.contadorPaginas.title = [NSString stringWithFormat:@"%d/%d", intContPaginas, intTotalPaginas];
    
    return arrayFilmes.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // Codigo para o banco de dados
    static NSString *identifier = @"CellFilme";
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    UIActivityIndicatorView *giragira = (UIActivityIndicatorView *)[cell viewWithTag:2];
    [giragira startAnimating];
    
    NSArray *arrayFilmes = [dicFilmes objectForKey:@"results"];
    
    NSDictionary *dispListaImage = [arrayFilmes objectAtIndex:indexPath.row];
    
    NSString *strJPG = [dispListaImage objectForKey:@"poster_path"];
    
    cell.backgroundColor = [UIColor blackColor];
    
    UIImageView *cellImageView = (UIImageView *)[cell viewWithTag:1];
    
    cellImageView.image = nil;
    
    if (![strJPG isEqual:[NSNull null]])
    {
        NSURL *imageURL = [NSURL URLWithString:[self.baseURLImagens stringByAppendingString:strJPG]];
        
        [self imagemURL:imageURL jpg:strJPG callback:^(UIImage *imagem, NSURL *url) {
            
            cellImageView.image = imagem;
            
            [giragira stopAnimating];
            [giragira setHidden:YES];
            
        }];
    }
    
    
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"Cliquei");
    
    NSArray *arrayFilmes = [dicFilmes objectForKey:@"results"];
    
    NSDictionary *dicFilmeSelecionado = [arrayFilmes objectAtIndex:indexPath.row];
    
    self.dicDescFilmeSelecionado = dicFilmeSelecionado;
    self.idFilmeSelecionado = [dicFilmeSelecionado objectForKey:@"id"];
    
    
    NSString *strJPG = [dicFilmeSelecionado objectForKey:@"poster_path"];
    
    if (![strJPG isEqual:[NSNull null]])
    {
        NSURL *imageURL = [NSURL URLWithString:[self.baseURLImagens stringByAppendingString:strJPG]];
        
        [self imagemURL:imageURL jpg:strJPG callback:^(UIImage *imagem, NSURL *url) {
            
            self.imageFilmeSelecionado = imagem;
            
        }];
    }
    
    // para fechar o menu se estiver aberto
    [self.rootNav setIsOpen:YES];
    
    [self.rootNav drawerToggle];
    //
    
    [self.navigationController setToolbarHidden:YES animated:YES];
    
    [self performSegueWithIdentifier:@"segueDetalhes" sender:nil];
}

#pragma mark - Configuração do API
// popula o dicionario de Configurações
- (void)configuracaoAPI
{
    NSString *urlString = [NSString stringWithFormat:@"%@/configuration?api_key=%@", self.baseURLAPI, self.chaveApi];
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *err)
     {
         if(data)
             dicConfiguracao = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
         else
             dicConfiguracao = nil;
     }];
}

- (void)retornaFilmes
{
    NSString *urlString = [NSString stringWithFormat:@"%@/discover/movie?api_key=%@", self.baseURLAPI, self.chaveApi];
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *err)
     {
         if(data)
         {
             dicFilmes = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
             
             [self.collectionView reloadData];
         }
         else
             dicFilmes = nil;
     }];
}

- (void)retornaFilmes_pagina:(int)pag
{
    NSString *urlString = [NSString stringWithFormat:@"%@/discover/movie?api_key=%@&page=%d%@", self.baseURLAPI, self.chaveApi, pag, strFiltro];
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *err)
     {
         if(data)
         {
             dicFilmes = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
             
             [self.collectionView reloadData];
         }
         else
             dicFilmes = nil;
     }];
}

- (void)retornaFilmes_filtro:(NSString *)filtro
{
    NSString *urlString = [NSString stringWithFormat:@"%@/discover/movie?api_key=%@&%@", self.baseURLAPI, self.chaveApi, filtro];
    
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *err)
     {
         if(data)
         {
             dicFilmes = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
             
             [self.collectionView reloadData];
         }
         else
             dicFilmes = nil;
     }];
}

- (void)imagemURL:(NSURL*)url jpg:(NSString *)jpg callback:(void (^)(UIImage *imagem, NSURL *url))callback
{
    if (!url)
        NSLog(@"URL inválido!!!");
    else
    {
        NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        NSString *cacheDir = [documentsPath stringByAppendingPathComponent:@"imagens"];
        
        [[NSFileManager defaultManager] createDirectoryAtPath:cacheDir withIntermediateDirectories:YES attributes:nil error:nil];
        
        NSString *imagePath = [cacheDir stringByAppendingPathComponent:jpg];
        
        if ([[NSFileManager defaultManager] fileExistsAtPath:imagePath])
            callback([UIImage imageWithContentsOfFile:imagePath], url);
        else
        {
            NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
                
                NSData *data = [NSData dataWithContentsOfURL:url];
                
                if (data)
                    [data writeToFile:imagePath atomically:YES];
                
                UIImage *loadedImage = [UIImage imageWithData:data];
                
                dispatch_async(dispatch_get_main_queue(),
                ^{
                    callback(loadedImage, url);
                });
            }];
            [queue addOperation:operation];
        }
    }
}


#pragma mark - montando propriedades

- (NSString *)chaveApi
{
    return CHAVE_API;
}

- (NSString *)baseURLAPI
{
    return BASE_URL_API;
}

- (NSString *)baseURLImagens
{
    return BASE_URL_IMAGEM;
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"segueDetalhes"])
    {
        TBDetalhe *det = (TBDetalhe *)segue.destinationViewController;
        
        det.idFilme = self.idFilmeSelecionado;
        det.dicDescFilme = self.dicDescFilmeSelecionado;
        det.imageFilme = self.imageFilmeSelecionado;
        
    }
}

#pragma mark - Botoes

- (IBAction)brnPraFrente:(id)sender
{
    if (intContPaginas == 1)
        [self.botaoVoltar setEnabled:YES];
    
    intContPaginas++;
    
    self.contadorPaginas.title = [NSString stringWithFormat:@"%d/%d", intContPaginas, intTotalPaginas];
    
    [self retornaFilmes_pagina:intContPaginas];
}

- (IBAction)btnVoltar:(id)sender
{
    if (intContPaginas == 2)
        [self.botaoVoltar setEnabled:NO];
    
    intContPaginas--;
    
    self.contadorPaginas.title = [NSString stringWithFormat:@"%d/%d", intContPaginas, intTotalPaginas];
    
    [self retornaFilmes_pagina:intContPaginas];
}

- (IBAction)btnMenu:(id)sender
{
    [self.rootNav drawerToggle];
}


#pragma mark - evento do Menu

- (void)CCKFNavDrawerSelection:(NSInteger)selectionRowIndex selectionSection:(NSInteger)selectionSection
{
    switch (selectionRowIndex)
    {
        case 0: // Todos os Filmes
        {
            strFiltro = @"";
            [self retornaFilmes_filtro:strFiltro];
            
        } break;
            
        case 1: // Mais populares
        {
            strFiltro = @"&sort_by=popularity.desc";
            [self retornaFilmes_filtro:strFiltro];
            
        } break;
            
        case 2: // Mais votados
        {
            strFiltro = @"&sort_by=vote_average.desc";
            [self retornaFilmes_filtro:strFiltro];
            
        } break;
            
        default:
            break;
    }
    
    [self.botaoVoltar setEnabled:NO];
    
    intContPaginas = 1;
    
    self.contadorPaginas.title = [NSString stringWithFormat:@"%d/%d", intContPaginas, intTotalPaginas];
    
}

@end
