

#import <UIKit/UIKit.h>

@interface DrawerView : UIView

@property (weak, nonatomic) IBOutlet UITableView *drawerTableView;

@end
