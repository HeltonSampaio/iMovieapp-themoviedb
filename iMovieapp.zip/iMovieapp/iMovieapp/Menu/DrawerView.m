

#import "DrawerView.h"

#define IS_IPHONE5 (([[UIScreen mainScreen] bounds].size.height-568)?NO:YES)
#define ALTURA_CABECALHO 65

@implementation DrawerView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


// Substituir Apenas drawRect: se você executar desenho personalizado.
// Uma implementação vazio afeta negativamente o desempenho durante a animação.
- (void)drawRect:(CGRect)rect
{    
    self.drawerTableView.frame = CGRectMake(0, 0, 225, (([[UIScreen mainScreen] bounds].size.height)-ALTURA_CABECALHO));
    
}


@end
