//
//  AppDelegate.h
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 02/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

