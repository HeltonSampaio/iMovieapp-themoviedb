//
//  CustomCellTitulo.m
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 03/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import "CustomCellTitulo.h"

@interface CustomCellTitulo ()

@property (weak, nonatomic) IBOutlet UILabel *labelTitulo;


@end

@implementation CustomCellTitulo

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
//    self.labelTitulo.textColor = [UIColor darkGrayColor];
    
}

#pragma mark - variaveis

- (void)setLblTitulo:(NSString *)lblTitulo
{
    self.labelTitulo.text = lblTitulo;
}

- (NSString *)lblTitulo
{
    return self.labelTitulo.text;
}



@end
