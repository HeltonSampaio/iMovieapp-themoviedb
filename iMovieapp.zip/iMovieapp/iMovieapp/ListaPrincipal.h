//
//  ListaPrincipal.h
//  iMovieapp
//
//  Created by Helton Fernandes Sampaio on 02/03/16.
//  Copyright (c) 2016 heltonapp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "CCKFNavDrawer.h"

@interface ListaPrincipal : UIViewController <UICollectionViewDelegate, UICollectionViewDataSource, CCKFNavDrawerDelegate>

@property (nonatomic, readonly) NSString *chaveApi;
@property (nonatomic, readonly) NSString *baseURLImagens;
@property (nonatomic, readonly) NSString *baseURLAPI;

@property (nonatomic) NSString *idFilmeSelecionado;
@property (nonatomic) NSDictionary *dicDescFilmeSelecionado;
@property (nonatomic) UIImage *imageFilmeSelecionado;

@end
